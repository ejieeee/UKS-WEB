import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.js';
import { PortalAbsensi } from './components/PortalAbsensi.js';
import { PortalAdmin } from './components/PortalAdmin.js';

export default function App() {
  const [activePortal, setActivePortal] = useState<'absensi' | 'admin'>('absensi');
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('pmr_admin_token') || null;
  });
  const [adminUsername, setAdminUsername] = useState<string | null>(() => {
    return localStorage.getItem('pmr_admin_username') || null;
  });

  useEffect(() => {
    if (adminToken) {
      fetch('/api/admin/me', {
        headers: { Authorization: `Bearer ${adminToken}` },
      })
        .then((res) => {
          if (!res.ok) {
            handleLogout();
          }
        })
        .catch(() => {
          // Network issue
        });
    }
  }, [adminToken]);

  const handleLoginSuccess = (token: string, username: string) => {
    setAdminToken(token);
    setAdminUsername(username);
    localStorage.setItem('pmr_admin_token', token);
    localStorage.setItem('pmr_admin_username', username);
  };

  const handleLogout = () => {
    setAdminToken(null);
    setAdminUsername(null);
    localStorage.removeItem('pmr_admin_token');
    localStorage.removeItem('pmr_admin_username');
  };

  const handleUpdateAdmin = (newUsername: string, newToken: string) => {
    setAdminToken(newToken);
    setAdminUsername(newUsername);
    localStorage.setItem('pmr_admin_token', newToken);
    localStorage.setItem('pmr_admin_username', newUsername);
  };

  return (
    <div className="min-h-screen bg-[#F8F6F0] flex flex-col text-[#343630] selection:bg-[#C99491]/30 selection:text-[#343630]">
      {/* Top Navbar */}
      <Navbar
        activePortal={activePortal}
        onSelectPortal={(portal) => setActivePortal(portal)}
        isAdminLoggedIn={!!adminToken}
      />

      {/* Main Content: Only Two Portals */}
      <div className="flex-1">
        {activePortal === 'absensi' ? (
          <PortalAbsensi />
        ) : (
          <PortalAdmin
            token={adminToken}
            adminUsername={adminUsername}
            onLoginSuccess={handleLoginSuccess}
            onLogout={handleLogout}
            onUpdateAdmin={handleUpdateAdmin}
          />
        )}
      </div>

      {/* Vintage Editorial Stationery Footer */}
      <footer className="border-t border-[#EAE3D7] bg-[#F8F6F0]/80 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#85847D]">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#984B50]"></span>
            <span className="font-serif font-semibold text-[#343630]">Palang Merah Remaja Wira</span>
            <span>·</span>
            <span className="font-editorial italic">"Siamo Tutti Fratelli" (Kita Semua Bersaudara)</span>
          </div>
          <div className="font-sans text-[11px] text-[#85847D]">
            Buku Induk Presensi Digital · Standar Waktu: Asia/Makassar (WITA, UTC+8)
          </div>
        </div>
      </footer>
    </div>
  );
}
